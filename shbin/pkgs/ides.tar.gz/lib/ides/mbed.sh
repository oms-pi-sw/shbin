#!/usr/bin/env bash

firefox https://os.mbed.com/compiler & 

exit 0
