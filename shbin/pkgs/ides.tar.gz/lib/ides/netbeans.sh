#!/usr/bin/env bash
if [ "$EUID" -ne 0 ]
	then echo "Please run as root"
	exit 1
fi

/usr/local/netbeans-8.2/bin/netbeans 

exit 0
