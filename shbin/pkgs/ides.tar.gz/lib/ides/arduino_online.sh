#!/usr/bin/env bash

firefox https://create.arduino.cc/editor/NickF93 & 

exit 0
