#!/usr/bin/env bash

rstudio 

exit 0
