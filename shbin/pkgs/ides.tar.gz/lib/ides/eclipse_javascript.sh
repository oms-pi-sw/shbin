#!/usr/bin/env bash

/home/nick/eclipse/javascript-oxygen/eclipse/eclipse 

exit 0
