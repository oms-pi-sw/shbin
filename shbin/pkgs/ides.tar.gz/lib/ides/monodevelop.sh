#!/usr/bin/env bash

monodevelop 

exit 0
