#!/usr/bin/env bash

idle3 

exit 0
