#!/usr/bin/env bash

/home/nick/liclipse/LiClipse 

exit 0
