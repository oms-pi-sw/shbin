#!/usr/bin/env bash

/home/nick/Downloads/arduino/arduino-1.8.4/arduino 

exit 0
