#!/usr/bin/env bash

gedit 

exit 0
