#!/usr/bin/env bash

atom 

exit 0
