#!/usr/bin/env bash

/home/nick/eclipse/php-oxygen/eclipse/eclipse 

exit 0
