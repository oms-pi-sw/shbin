#!/usr/bin/env bash

/home/nick/eclipse/java-oxygen/eclipse/eclipse 

exit 0
