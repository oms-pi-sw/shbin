#!/usr/bin/env bash

/home/nick/eclipse/cpp-oxygen/eclipse/eclipse 

exit 0
