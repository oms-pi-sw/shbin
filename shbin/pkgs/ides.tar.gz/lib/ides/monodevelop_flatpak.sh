#!/usr/bin/env bash

flatpak run com.xamarin.MonoDevelop 

exit 0
