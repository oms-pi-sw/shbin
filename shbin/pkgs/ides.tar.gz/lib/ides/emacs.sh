#!/usr/bin/env bash

emacs 

exit 0
